To run the algorithm, just execute the python script "assignment9.py"
