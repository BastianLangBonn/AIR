package org.brsu.assignments.assignment1;

public enum Strategy {
  DEPTH_FIRST, BREADTH_FIRST
}