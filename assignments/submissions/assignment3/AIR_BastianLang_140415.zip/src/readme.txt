To run the code:
- open terminal and change to src-directory
- compile java code using javac org/brsu/assignments/assignment1/Application.java
- run code using java org.brsu.assignments.assignment1.Application

This command will run the agent two times for each given map, one time using a BFS approach, the other time using DFS approach.
In the folder src/resources/results will then be created the result files. For every approach there is one file containing the
 final map configuration and some statistics.
For every approach there will also be a file containing all the map configurations for every single step taken.
