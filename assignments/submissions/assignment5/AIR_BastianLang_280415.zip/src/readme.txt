To run the code:
- open terminal and change to src-directory
- compile java code using 'javac org/brsu/assignments/assignment5/application/Application.java'
- run code using 'java org.brsu.assignments.assignment5.application.Application'

This will start runs for Greedy and A* with every heuristic for 10 randomly created start configurations.
The result will be *appended* at the result file in the resource folder.
