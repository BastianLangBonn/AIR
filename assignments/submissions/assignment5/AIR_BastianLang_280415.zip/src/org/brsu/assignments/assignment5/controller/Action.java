package org.brsu.assignments.assignment5.controller;

public enum Action {
  RIGHT, DOWN, UP, LEFT

}
