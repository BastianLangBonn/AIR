package org.brsu.assignments.model;

public enum Strategy {
  DEPTH_FIRST, BREADTH_FIRST
}