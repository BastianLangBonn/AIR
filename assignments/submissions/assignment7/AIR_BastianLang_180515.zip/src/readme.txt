To run the code:
- open terminal and change to src-directory
- compile java code using 'javac org/brsu/assignments/assignment7/control/TravellingSalesmanRunner.java'
- run code using 'java org.brsu.assignments.assignment7.control.TravellingSalesmanRunner'

This will start the kMeans-approach and prints out some paths in text form, but the paths seem to be wrong and there is no visualization yet.
