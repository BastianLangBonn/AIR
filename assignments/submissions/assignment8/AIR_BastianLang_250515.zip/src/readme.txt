To run the code, please change into the folder 'src' and compile via:
javac org/brsu/assignments/assignment8/control/SimulatedAnnealing.java

Then use the following command to execute:
java org.brsu.assignments.assignment8.control.SimulatedAnnealing 1

Please note that the 1 denotes the number of minutes the computation should take place. Also if omitted the
program will probably crash.
